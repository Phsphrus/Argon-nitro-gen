import random
import os
from colorama import init, Fore, Style

def gen():
    init()  # Initialize colorama

    length = 16
    upper_letter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    lower_letter = 'abcdefghijklmnopqrstuvwxyz'
    digits = '0123456789'

    print(Fore.LIGHTBLUE_EX + """
░█████╗░██████╗░░██████╗░░█████╗░███╗░░██╗  ███╗░░██╗██╗████████╗██████╗░░█████╗░  ░██████╗░███████╗███╗░░██╗
██╔══██╗██╔══██╗██╔════╝░██╔══██╗████╗░██║  ████╗░██║██║╚══██╔══╝██╔══██╗██╔══██╗  ██╔════╝░██╔════╝████╗░██║
███████║██████╔╝██║░░██╗░██║░░██║██╔██╗██║  ██╔██╗██║██║░░░██║░░░██████╔╝██║░░██║  ██║░░██╗░█████╗░░██╔██╗██║
██╔══██║██╔══██╗██║░░╚██╗██║░░██║██║╚████║  ██║╚████║██║░░░██║░░░██╔══██╗██║░░██║  ██║░░╚██╗██╔══╝░░██║╚████║
██║░░██║██║░░██║╚██████╔╝╚█████╔╝██║░╚███║  ██║░╚███║██║░░░██║░░░██║░░██║╚█████╔╝  ╚██████╔╝███████╗██║░╚███║
╚═╝░░╚═╝╚═╝░░╚═╝░╚═════╝░░╚════╝░╚═╝░░╚══╝  ╚═╝░░╚══╝╚═╝░░░╚═╝░░░╚═╝░░╚═╝░╚════╝░  ░╚═════╝░╚══════╝╚═╝░░╚══╝""" + Style.RESET_ALL)
    Number0Codes = input(Fore.RED + "How many nitro codes do you want to generate?: " + Style.RESET_ALL)
    upper, lower, nums = True, True, True
    all = ""

    if upper:
        all += upper_letter
        if lower:
            all += lower_letter
        if nums:
            all += digits

    Save = input(Fore.RED + "Do you want to save the codes to a file? (y/n): " + Style.RESET_ALL)
    if Save == "y":
        script_dir = os.path.dirname(os.path.abspath(__file__))
        NitroCodess = os.path.join(script_dir, "NitroCodes")
        if not os.path.exists(NitroCodess):
            os.makedirs(NitroCodess)

        file_path = os.path.join(NitroCodess, "result.txt")

        with open(file_path, 'w') as file:
            for x in range(int(Number0Codes)):
                nitro = ''.join(random.sample(all, length))
                file.write('discord.gift/' + nitro + '\n')
                print(Fore.LIGHTBLUE_EX + 'discord.gift/' + nitro + Style.RESET_ALL)

              

        print(Fore.RED + """░██╗░░░░░░░██╗░█████╗░██████╗░███╗░░██╗██╗███╗░░██╗░██████╗░
░██║░░██╗░░██║██╔══██╗██╔══██╗████╗░██║██║████╗░██║██╔════╝░
░╚██╗████╗██╔╝███████║██████╔╝██╔██╗██║██║██╔██╗██║██║░░██╗░
░░████╔═████║░██╔══██║██╔══██╗██║╚████║██║██║╚████║██║░░╚██╗
░░╚██╔╝░╚██╔╝░██║░░██║██║░░██║██║░╚███║██║██║░╚███║╚██████╔╝
░░░╚═╝░░░╚═╝░░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚══╝╚═╝╚═╝░░╚══╝░╚═════╝░""" + Style.RESET_ALL)
        print(Fore.RED + "ALL CODES ARE RANDOMLY GENERATED. THEY MIGHT NOT BE VALID!" + Style.RESET_ALL)
    else:
        for x in range(int(Number0Codes)):
            nitro = ''.join(random.sample(all, length))
            print(Fore.LIGHTBLUE_EX + 'discord.gift/' + nitro + Style.RESET_ALL)
        print(Fore.RED + """░██╗░░░░░░░██╗░█████╗░██████╗░███╗░░██╗██╗███╗░░██╗░██████╗░
░██║░░██╗░░██║██╔══██╗██╔══██╗████╗░██║██║████╗░██║██╔════╝░
░╚██╗████╗██╔╝███████║██████╔╝██╔██╗██║██║██╔██╗██║██║░░██╗░
░░████╔═████║░██╔══██║██╔══██╗██║╚████║██║██║╚████║██║░░╚██╗
░░╚██╔╝░╚██╔╝░██║░░██║██║░░██║██║░╚███║██║██║░╚███║╚██████╔╝
░░░╚═╝░░░╚═╝░░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚══╝╚═╝╚═╝░░╚══╝░╚═════╝░""" + Style.RESET_ALL)
        print(Fore.RED + "ALL CODES ARE RANDOMLY GENERATED. THEY MIGHT NOT BE VALID!" + Style.RESET_ALL)

    input(Fore.LIGHTBLUE_EX + "Press Enter to exit..." + Style.RESET_ALL)


if __name__ == '__main__':
    gen()
